package com.example.calcolator.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

import com.example.calcolator.model.BmiHistory;

import java.util.ArrayList;
import java.util.Optional;

/**
 * Created by Vlado on 26.11.2017 г..
 */

public class DBHelper extends SQLiteOpenHelper {
    SQLiteDatabase db;
    public static final String LOG = "dbException";

    public static final String DB_NAME = "dbToDoList.db";
    public static final int DB_VERSION = 1;
    //Tale CONTACT
    public static final String TABLE_BMI_HISTORY = "bmi_history";
    //table CONTACT columns
    public static final String BMI_HISTORY_COLUMN_ID = "_id";
    public static final String BMI_HISTORY_COLUMN_HEIGHT_IN_CM = "height_in_cm";
    public static final String BMI_HISTORY_COLUMN_WEIGHT_IN_KG = "weight_in_kg";
    public static final String BMI_HISTORY_COLUMN_BMI_RESULT = "bmi_result";

    public static final String CREATE_TABLE_BMI_HISTORY="CREATE TABLE "+TABLE_BMI_HISTORY+"("+
            "'" + BMI_HISTORY_COLUMN_ID + "' INTEGER PRIMARY KEY AUTOINCREMENT," +
            "'" + BMI_HISTORY_COLUMN_HEIGHT_IN_CM + "' REAL NOT NULL, " +
            "'" + BMI_HISTORY_COLUMN_WEIGHT_IN_KG + "' REAL NOT NULL, " +
            "'" + BMI_HISTORY_COLUMN_BMI_RESULT + "' REAL NOT NULL)";


    public DBHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
      sqLiteDatabase.execSQL(CREATE_TABLE_BMI_HISTORY);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
      sqLiteDatabase.execSQL("DROP TABLE IF EXISTS "+TABLE_BMI_HISTORY);
        onCreate(sqLiteDatabase);
    }
public void addBmiHistory(BmiHistory bmiHistory, Context context){

    try {
        db = getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(BMI_HISTORY_COLUMN_HEIGHT_IN_CM, bmiHistory.getHeightInCm());
        cv.put(BMI_HISTORY_COLUMN_WEIGHT_IN_KG,bmiHistory.getWeightInKg());
        cv.put(BMI_HISTORY_COLUMN_BMI_RESULT,bmiHistory.getBmiResult());

        db.insertOrThrow(TABLE_BMI_HISTORY, null, cv);
    }catch (SQLException e){
        Toast.makeText(context, "Something's wrong!!!",
                Toast.LENGTH_LONG).show();
        Log.e(LOG, e.getMessage());
    }finally {
        if(db != null)
            db.close();
    }
}


    public void deleteBmiHistory(long id){
        try {
            db =getWritableDatabase();
            db.execSQL("delete from "+TABLE_BMI_HISTORY+" where " + BMI_HISTORY_COLUMN_ID + " = " + id);
        }catch (SQLException e){
            Log.e(LOG, e.getMessage());
        }finally {
            if (db != null)
                db.close();
        }
    }
    public void updateBmiHistory(long id, BmiHistory bmiHistory, Context context) {
        Cursor c = null;
        try {
            db = getWritableDatabase();
            ContentValues cv = new ContentValues();

            cv.put(BMI_HISTORY_COLUMN_HEIGHT_IN_CM, bmiHistory.getHeightInCm());
            cv.put(BMI_HISTORY_COLUMN_WEIGHT_IN_KG,bmiHistory.getWeightInKg());
            cv.put(BMI_HISTORY_COLUMN_BMI_RESULT,bmiHistory.getBmiResult());
            db.update(TABLE_BMI_HISTORY,cv,BMI_HISTORY_COLUMN_ID + " = " + id,null);
        } catch (SQLException e) {
            Toast.makeText(context, "Something's wrong!!!",
                    Toast.LENGTH_LONG).show();
            Log.e(LOG, e.getMessage());
        } finally {

            if (db != null)
                db.close();
        }
    }

    public ArrayList<BmiHistory> getAllBmiHistory(){
        ArrayList<BmiHistory> list =new ArrayList<>();
        Cursor c = null;

        try {
            String query = "SELECT * FROM " + TABLE_BMI_HISTORY;

            db =getReadableDatabase();
            c = db.rawQuery(query, null);
            if (c.moveToFirst()) {
                do {
                    final BmiHistory bmiHistory = new BmiHistory();
                    bmiHistory.setId(c.getLong(c.getColumnIndex(BMI_HISTORY_COLUMN_ID)));
                    bmiHistory.setHeightInCm(c.getDouble(c.getColumnIndex(BMI_HISTORY_COLUMN_HEIGHT_IN_CM)));
                    bmiHistory.setWeightInKg(c.getDouble(c.getColumnIndex(BMI_HISTORY_COLUMN_WEIGHT_IN_KG)));
                    bmiHistory.setBmiResult(c.getDouble(c.getColumnIndex(BMI_HISTORY_COLUMN_BMI_RESULT)));
                    list.add(bmiHistory);
                } while (c.moveToNext());
            }
        }catch (SQLException e){
            Log.e(LOG, e.getMessage());
        }finally {
            if(c != null)
                c.close();
            if(db != null)
                db.close();
        }
        return list;
    }

    public Optional<BmiHistory> findById(long id) {
        Cursor c = null;

        try {
            String query = "SELECT * FROM " + TABLE_BMI_HISTORY + " WHERE " + BMI_HISTORY_COLUMN_ID + " = " + id;

            db =getReadableDatabase();
            c = db.rawQuery(query, null);
            if (c.moveToFirst()) {
                    final BmiHistory bmiHistory = new BmiHistory();
                    bmiHistory.setId(c.getLong(c.getColumnIndex(BMI_HISTORY_COLUMN_ID)));
                    bmiHistory.setHeightInCm(c.getDouble(c.getColumnIndex(BMI_HISTORY_COLUMN_HEIGHT_IN_CM)));
                    bmiHistory.setWeightInKg(c.getDouble(c.getColumnIndex(BMI_HISTORY_COLUMN_WEIGHT_IN_KG)));
                    bmiHistory.setBmiResult(c.getDouble(c.getColumnIndex(BMI_HISTORY_COLUMN_BMI_RESULT)));
                    return Optional.of(bmiHistory);
            }
        }catch (SQLException e){
            Log.e(LOG, e.getMessage());
        }finally {
            if(c != null)
                c.close();
            if(db != null)
                db.close();
        }
        return Optional.empty();
    }
}
