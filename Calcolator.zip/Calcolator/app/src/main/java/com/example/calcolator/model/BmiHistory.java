package com.example.calcolator.model;

public class BmiHistory {
    private Long id;
    private Double heightInCm;
    private Double weightInKg;
    private Double bmiResult;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Double getHeightInCm() {
        return heightInCm;
    }

    public void setHeightInCm(Double heightInCm) {
        this.heightInCm = heightInCm;
    }

    public Double getWeightInKg() {
        return weightInKg;
    }

    public void setWeightInKg(Double weightInKg) {
        this.weightInKg = weightInKg;
    }

    public Double getBmiResult() {
        return bmiResult;
    }

    public void setBmiResult(Double bmiResult) {
        this.bmiResult = bmiResult;
    }
}
