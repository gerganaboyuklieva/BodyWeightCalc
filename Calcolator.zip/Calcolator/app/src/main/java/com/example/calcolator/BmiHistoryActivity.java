package com.example.calcolator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import com.example.calcolator.adapter.BmiHistoryAdapter;
import com.example.calcolator.db.DBHelper;
import com.example.calcolator.model.BmiHistory;

import java.util.ArrayList;

public class BmiHistoryActivity extends AppCompatActivity {
    private ListView bmiHistoryListView;
    private BmiHistoryAdapter adapter;
    private ArrayList<BmiHistory> items = new ArrayList<>();
    private DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bmi_history);
        this.bmiHistoryListView = this.findViewById(R.id.bmiHistoryList);
        this.dbHelper = new DBHelper(this);
        items = dbHelper.getAllBmiHistory();
        this.adapter = new BmiHistoryAdapter(this, items, R.layout.adapter_delete_layout);
        this.bmiHistoryListView.setAdapter(this.adapter);
    }
}