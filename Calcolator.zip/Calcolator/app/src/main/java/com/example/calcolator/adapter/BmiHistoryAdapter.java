package com.example.calcolator.adapter;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.TextView;

import com.example.calcolator.R;
import com.example.calcolator.db.DBHelper;
import com.example.calcolator.model.BmiHistory;

import java.util.ArrayList;

public class BmiHistoryAdapter  extends BaseAdapter implements ListAdapter {
    private Context context;
    private ArrayList<BmiHistory> items;
    int id;
    Dialog customDialog;
    DBHelper dbHelper;

    public BmiHistoryAdapter(Context context, ArrayList<BmiHistory> items, int id) {
        this.context = context;
        this.items = items;
        this.id=id;

    }


    @Override


    public int getCount() {
        return items.size();
    }

    @Override
    public Object getItem(int i) {
        return items.get(i);
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @SuppressLint("SetTextI18n")
    @Override
    public View getView(final int i, View view, ViewGroup parent) {

        if (view == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view= inflater.inflate(id, null);
        }
        final BmiHistory bmiHistory = items.get(i);
        if(id == R.layout.adapter_delete_layout) {
            TextView tv = (TextView) view.findViewById(R.id.adapterUpdateDeleteTextView);

            tv.setText(this.getBMIHistoryDisplayString(bmiHistory));
            ImageView deleteImageView = (ImageView) view.findViewById(R.id.adapterDeleteImageView);

            View.OnClickListener onClick=new View.OnClickListener() {
                @Override

                public void onClick(View v) {
                    dbHelper=new DBHelper(context);
                    if(v.getId() == R.id.adapterDeleteImageView){
                        dbHelper.deleteBmiHistory(bmiHistory.getId());
                        items.remove(i);
                        notifyDataSetChanged();

                    }
                }
            };
            deleteImageView.setOnClickListener(onClick);
        }
        return view;

    }

    private String getBMIHistoryDisplayString(BmiHistory bmiHistory) {
        return bmiHistory.getHeightInCm() + " cm | " + bmiHistory.getWeightInKg() + " kg | " + String.format("%.2f", bmiHistory.getBmiResult()) + " BMI";
    }
}
