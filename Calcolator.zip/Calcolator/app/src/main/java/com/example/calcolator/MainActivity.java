package com.example.calcolator;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button calculatorBtn;
    private Button historyBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.calculatorBtn = (Button) this.findViewById(R.id.calculatorBtn);
        this.historyBtn = (Button) this.findViewById(R.id.historyBtn);
        this.calculatorBtn.setOnClickListener(new ChangeActivityOnClickListener<>(CalculatorActivity.class));
        this.historyBtn.setOnClickListener(new ChangeActivityOnClickListener<>(BmiHistoryActivity.class));
    }

    private <T extends Activity> void changeActivity (final Class<T> activityClass) {
        Intent intent = new Intent(this, activityClass);
        startActivity(intent);
    }

    private class ChangeActivityOnClickListener<T extends Activity> implements View.OnClickListener {
        private final Class<T> activityClass;
        public ChangeActivityOnClickListener(final Class<T> activityClass){
            this.activityClass = activityClass;
        }
        @Override
        public void onClick(View v) {
            MainActivity.this.changeActivity(activityClass);
        }
    }
}