package com.example.calcolator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.calcolator.db.DBHelper;
import com.example.calcolator.model.BmiHistory;

public class CalculatorActivity extends AppCompatActivity {
    private EditText heightEditText;
    private EditText weightEditText;
    private TextView resultTextView;
    private Button calculateBtn;
    private DBHelper dbHelper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculator);
        this.dbHelper = new DBHelper(this);
        this.heightEditText = this.findViewById(R.id.inputHeight);
        this.weightEditText = this.findViewById(R.id.inputWeight);
        this.resultTextView = this.findViewById(R.id.bmiResult);
        this.calculateBtn = this.findViewById(R.id.calculateBtn);
        this.calculateBtn.setOnClickListener(onClick);
    }

    private View.OnClickListener onClick= v -> {
        final Double height = Double.valueOf(this.heightEditText.getText().toString());
        final Double weight = Double.valueOf(this.weightEditText.getText().toString());
        if(height == null || weight == null) {
            Toast.makeText(this, "height and weight can not be null!",
                    Toast.LENGTH_LONG).show();
            return;
        }
        final Double result = weight / Math.pow((height / 100D), 2);
        this.resultTextView.setText("Your BMI is : " + String.format("%.2f", result));
        final BmiHistory history = new BmiHistory();
        history.setHeightInCm(height);
        history.setWeightInKg(weight);
        history.setBmiResult(result);
        this.dbHelper.addBmiHistory(history,this);
    };
}